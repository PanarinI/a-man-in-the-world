# DESCRIPTION

Reads a Photoshop palette file on standard input and writes a GIMP palette file on standard output.

# USAGE

	aco2gpl < foo.aco > bar.gpl

# CREDITS

This is a hack of [aco2html](https://github.com/mindscratch/aco2html).
